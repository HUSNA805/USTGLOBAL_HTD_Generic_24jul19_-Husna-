export class User {
    constructor(
        public Brand:string,
        public Model:number,
        public YOR:number,
        public Cost:number){}
}
